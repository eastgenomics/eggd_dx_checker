## What does this script do?

East Genomics private Slack bot ! It sends messages only (for now :3)

## What are typical use cases for this script?

When doing checks, use this script to send messages to either egg-logs or egg-alerts

## What is required for this script to run?

Needs Python > 3.6 because of slackclient.

Usage:
python hermes.py msg "Message to send" token-file slack_channel [-v]

### This was made by EMEE GLH
