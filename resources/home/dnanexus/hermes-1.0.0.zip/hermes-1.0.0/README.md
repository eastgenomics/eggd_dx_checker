# hermes

East Genomics private Slack bot !

This repo uses slackclient to send messages to the egg-alerts channel in binfx.
Needs Python3.6

Usage:
python hermes.py msg "Message to send"
